import setuptools

import test_big


setuptools.setup(
    name="test_big",
    description='',
    url='',
    author='Serov Aleksander',
    author_email='serov@selectel.ru',
    packages=['test_big']
)